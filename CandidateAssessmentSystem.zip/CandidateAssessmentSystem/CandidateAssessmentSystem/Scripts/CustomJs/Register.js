﻿$(document).ready(function () {
    var ReadBool = false;
});
function Add() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var RegUser = {
        FirstName: $('#FirstName').val(),
        LastName: $('#LastName').val(),
        Email: $('#Email').val(),
        PhoneCode: $('#PhoneCode').val(),
        City: $('#City').val(),
        State: $('#State').val(),
        Country: $('#Country').val(),
        Pincode: $('#Pincode').val(),

    };
    $.ajax({
        url: "/Registration/Save",
        data: JSON.stringify(RegUser),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            console.log(RegUser)
            alert("Registration Successful")
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

function clear() {
    $('#cdid').val("");
    $('#FirstName').val("");
    $('#btnUpdate').hide();
    $('#btnAdd').show();
    $('#ItemName').css('border-color', 'lightgrey');
}
function validate() {
    var isValid = true;
    if ($('#FirstName').val().trim() == "") {
        $('#FirstName').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#FirstName').css('border-color', 'lightgrey');
    }
    if ($('#Email').val().trim() == "") {
        $('#Email').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Email').css('border-color', 'lightgrey');
    }
    if ($('#Country').val().trim() == "") {
        $('#Country').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Country').css('border-color', 'lightgrey');
    }
    return isValid;
}