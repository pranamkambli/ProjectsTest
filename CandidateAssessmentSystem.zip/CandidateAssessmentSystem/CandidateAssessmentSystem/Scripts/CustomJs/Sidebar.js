﻿$(document).ready(function () {
    MenuLarge();
});
function MenuLarge() {
    document.getElementById("Sidebar").addEventListener("mouseover", mouseOver);
    document.getElementById("Sidebar").addEventListener("mouseout", mouseOut);
    //document.getElementById("MenueButton").addEventListener("mouseout", mouseOut);
    document.querySelector(".dropdown").addEventListener("mouseover", mouseOver);
}
function mouseOver() {
    document.getElementById("MenueButton").style.width = "200px";
    document.getElementById("MenueButton").style.transition = "all 300ms linear";
    document.getElementById("main").style.marginRight = "250px";
    document.getElementById("main").style.transition = "all 300ms linear";
    //document.querySelector(".dropbtn").style.background = "#2980B9";

}
function mouseOut() {
    document.getElementById("MenueButton").style.width = "50px";
    document.getElementById("MenueButton").style.transition = "all 0ms linear";
    document.getElementById("main").style.marginRight = "0px";
    document.getElementById("main").style.transition = "all 0ms linear";
}

function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
function myFunction2() {
    document.getElementById("myDropdown2").classList.toggle("show");
}
window.onclick = function (event) {
    if (!event.target.matches('.dropbtn')) {
        var dropdowns = document.querySelector(".dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}
window.onclick = function (event) {
    if (!event.target.matches('.dropbtn2')) {
        var dropdowns = document.querySelector(".dropdown-content2");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
            var openDropdown = dropdowns[i];
            if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
            }
        }
    }
}



