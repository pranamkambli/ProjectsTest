﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CandidateAssessmentSystem.Controllers
{
    public class ResetPasswordController : Controller
    {
        //
        // GET: /ResetPassword/

        public ActionResult Index()
        {
            return View();
        }

    }
}
