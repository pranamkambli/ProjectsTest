﻿$(document).ready(function () {
    loadData();
});
function loadData() {
    var SText = document.getElementById("SearchText");
    var SearchText = SText.value;
    $.ajax({
        url: "/ClientDetail/List/" + SearchText,
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        data: { SearchText: SearchText },
        success: function (result) {
            var html = '';
            $.each(result, function (key, item) {
                html += '<tr>';
                html += '<td style="display:none">' + item.ClientId + '</td>';
                html += '<td>' + item.ClientName + '</td>';
                html += '<td>' + item.ClientType + '</td>';
                html += '<td>' + item.Proprietor + '</td>';
                html += '<td>' + item.Main_Contact + '</td>';
                html += '<td>' + item.Person_Contact + '</td>';
                html += '<td>' + item.Email + '</td>';
                html += '<td>' + item.Address + '</td>';
                html += '<td>' + item.Location + '</td>';
                html += '<td>' + item.Documents + '</td>';
                html += '<td><a href="#" onclick="return getbyID(' + item.ClientId + ')">Edit</a> | <a href="#" onclick="Delele(' + item.ClientId + ')">Delete</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });

}


function Add() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var ClientObj = {
        //ClientId: $('#ClientId').val(),
        ClientName: $('#ClientName').val(),
        ClientType: $('#ClientTypeList').val(),
        Proprietor: $('#Proprietor').val(),
        Main_Contact: $('#MContact').val(),
        Person_Contact: $('#PContact').val(),
        Email: $('#Email').val(),
        Address: $('#Address').val(),
        Location: $('#Location').val(),
        Documents: $('#Documents').val(),
    };
    $.ajax({
        url: "/ClientDetail/Add",
        data: JSON.stringify(ClientObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            loadData();
            $('#ItemModal').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}
function getbyID(ItemId) {
    LoadDropdowns();
    $('#ClientName').css('border-color', 'lightgrey');
    $('#ClientTypeList').css('border-color', 'lightgrey');
    $('#Proprietor').css('border-color', 'lightgrey');
    $('#MContact').css('border-color', 'lightgrey');
    $('#PContact').css('border-color', 'lightgrey');
    $('#Email').css('border-color', 'lightgrey');
    $('#Address').css('border-color', 'lightgrey');
    $('#Location').css('border-color', 'lightgrey');
    $('#Documents').css('border-color', 'lightgrey');
    $.ajax({
        url: "/ClientDetail/getbyID/" + ItemId,
        typr: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            $('#ClientId').val(result.ClientId);
            $('#ClientName').val(result.ClientName);
            $('#ClientTypeList').val(result.ClientType);
            $('#Proprietor').val(result.Proprietor);
            $('#MContact').val(result.Main_Contact);
            $('#PContact').val(result.Person_Contact);
            $('#Email').val(result.Email);
            $('#Address').val(result.Address);
            $('#Location').val(result.Location);
            $('#Documents').val(result.Documents);
            $('#ItemModal').modal('show');
            $('#btnUpdate').show();
            $('#btnAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
function Update() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var empObj = {
        ClientId: $('#ClientId').val(),
        ClientName: $('#ClientName').val(),
        ClientType: $('#ClientTypeList').val(),
        Proprietor: $('#Proprietor').val(),
        Main_Contact: $('#MContact').val(),
        Person_Contact: $('#PContact').val(),
        Email: $('#Email').val(),
        Address: $('#Address').val(),
        Location: $('#Location').val(),
        Documents: $('#Documents').val(),
    };
    $.ajax({
        url: "/ClientDetail/Update",
        data: JSON.stringify(empObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            loadData();
            $('#ItemModal').modal('hide');
            $('#ClientId').val(""),
            $('#ClientName').val(""),
            $('#ClientTypeList').val(""),
            $('#Proprietor').val(""),
            $('#MContact').val(""),
            $('#PContact').val(""),
            $('#Email').val(""),
            $('#Address').val(""),
            $('#Location').val(""),
            $('#Documents').val("")
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}
function Delele(ID) {
    var ans = confirm("Are you sure you want to delete this Record?");
    if (ans) {
        $.ajax({
            url: "/ClientDetail/Delete/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {
                loadData();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
}
function LoadDropdowns() {
    $.ajax({
        type: "GET",
        url: "/ClientDetail/getClientType",
        data: "{}",
        success: function (data) {
            var s = '<option value="-1">Select Client Type</option>';
            for (var i = 0; i < data.length; i++) {
                s += '<option value="' + data[i].ClientTypeId + '">' + data[i].Client_Type + '</option>';
            }
            $("#ClientTypeList").html(s);
        }
    });
}
function clearTextBox() {
    LoadDropdowns();
    $('#ClientName').val("");
    $('#ClientTypeList').val("");
    $('#Proprietor').val("");
    $('#MContact').val("");
    $('#PContact').val("");
    $('#Email').val("");
    $('#Address').val("");
    $('#Location').val("");
    $('#Documents').val("");
    $('#btnUpdate').hide();
    $('#btnAdd').show();
    $('#ClientName').css('border-color', 'lightgrey');
    $('#ClientTypeList').css('border-color', 'lightgrey');
    $('#Proprietor').css('border-color', 'lightgrey');
    $('#MContact').css('border-color', 'lightgrey');
    $('#PContact').css('border-color', 'lightgrey');
    $('#Email').css('border-color', 'lightgrey');
    $('#Address').css('border-color', 'lightgrey');
    $('#Location').css('border-color', 'lightgrey');
    $('#Documents').css('border-color', 'lightgrey');
}
function validate() {
    var isValid = true;
    if ($('#ClientName').val().trim() == "") {
        $('#ClientName').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#ClientName').css('border-color', 'lightgrey');
    }

    if ($('#ClientTypeList').val().trim() == "-1") {
        $('#ClientTypeList').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#ClientTypeList').css('border-color', 'lightgrey');
    }

    if ($('#Location').val().trim() == "") {
        $('#Location').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Location').css('border-color', 'lightgrey');
    }

    if ($('#MContact').val().trim() == "") {
        $('#MContact').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#MContact').css('border-color', 'lightgrey');
    }
    return isValid;
}