﻿using CandidateAssessmentSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;

namespace CandidateAssessmentSystem.Controllers
{
    public class RegistrationController : Controller
    {
        //
        // GET: /Registration/
        CandiateManagerDBEntities candiateManage = null;
        public RegistrationController()
        {
            candiateManage = new CandiateManagerDBEntities();
        }
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult Save(User regusers)
        {
            try
            {
                candiateManage.Users.Add(regusers);
                candiateManage.SaveChanges();
                return Json(JsonRequestBehavior.AllowGet);

                var smtpClient = new SmtpClient("smtp.gmail.com") { Port = 587, Credentials = new NetworkCredential("email", "password"), EnableSsl = true, };
                smtpClient.Send("email", "recipient", "subject", "body");

                RedirectToAction("Index", "Login");


            }
            catch (Exception ex)
            {

                return Json(JsonRequestBehavior.AllowGet);
            }
        }

    }
}
