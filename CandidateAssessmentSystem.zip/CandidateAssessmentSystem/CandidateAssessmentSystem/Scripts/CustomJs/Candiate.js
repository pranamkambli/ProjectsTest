﻿$(document).ready(function () {
    var ReadBool = false;
    loadData();
});
function loadData() {
    var SText = document.getElementById("SearchText");
    var SearchText = SText.value;
    console.log("Serch", SearchText);
    $.ajax({
        url: "/Candiate/List/" + SearchText,
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        data: { SearchText: SearchText },
        success: function (result) {
            console.log("data: ", result)
            var html = '';
            $.each(result, function (key, item) {
                html += '<tr>';
                html += '<td style="display:none">' + item.cdid + '</td>';
                html += '<td>' + item.FirstName+" "+item.LastName  + '</td>';
                html += '<td>' + item.Email + '</td>';
                html += '<td>' + item.City + "" + item.Country + '</td>';
                html += '<td>' + item.Experience + '</td>';
                html += '<td> <a href="#" onclick="return getbyIdToView(' + item.cdid + ')">View</a> | <a href="#" onclick="return getbyIdToEdit(' + item.cdid + ')">Edit</a> | <a href="#" onclick="Delele(' + item.cdid + ')">Delete</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            //alert(errormessage.responseText);
        }
    });
}
function Add() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var CandObj = {
        FirstName: $('#FirstName').val(),
        LastName: $('#LastName').val(),
        Email: $('#Email').val(),
        PhoneCode: $('#PhoneCode').val(),
        City: $('#City').val(),
        State: $('#State').val(),
        Country: $('#Country').val(),
        Pincode: $('#Pincode').val(),
        Employer: $('#Employer').val(),
        Fromdate: $('#Fromdate').val(),
        Todate: $('#Todate').val(),

    };
    $.ajax({
        url: "/Candiate/Add",
        data: JSON.stringify(CandObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            console.log(CandObj)
            loadData();
            $('#ItemModal').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}
function getbyIdToView(cdid) {
    
    getbyID(cdid);
    PropertyRead(true);
    $('#ItemModal').modal('show');
    $('#btnAdd').hide();
    $('#btnUpdate').hide();
}
function getbyIdToEdit(cdid)
{
    getbyID(cdid);
    PropertyRead(false);
    $('#ItemModal').modal('show');
    $('#btnUpdate').show();
    $('#btnAdd').hide();
}
function PropertyRead(ReadBool)
{
    document.getElementById("FirstName").readOnly = ReadBool;
    document.getElementById("LastName").readOnly = ReadBool;
    document.getElementById("Email").readOnly = ReadBool;
    document.getElementById("PhoneCode").readOnly = ReadBool;
    document.getElementById("City").readOnly = ReadBool;
    document.getElementById("State").readOnly = ReadBool;
    document.getElementById("Country").readOnly = ReadBool;
    document.getElementById("Pincode").readOnly = ReadBool;
    document.getElementById("Employer").readOnly = ReadBool;
    document.getElementById("Fromdate").readOnly = ReadBool;
    document.getElementById("Todate").readOnly = ReadBool;
    document.getElementById("WrkExp").readOnly = ReadBool;
}
function getbyID(cdid) {
    $.ajax({
        url: "/Candiate/getbyID/" + cdid,
        data: { Cdid: cdid },
        typr: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            $('#cdid').val(result.cdid);
            $('#FirstName').val(result.FirstName);
            $('#LastName').val(result.LastName);
            $('#Email').val(result.Email);
            $('#PhoneCode').val(result.PhoneCode);
            $('#City').val(result.City);
            $('#State').val(result.State);
            $('#Country').val(result.Country);
            $('#Pincode').val(result.Pincode);
            $('#Employer').val(result.Employer);
            $('#Fromdate').val(result.Fromdate);
            $('#Todate').val(result.Todate);
            
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
function Update() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var CandObj = {
        Cdid: $('#cdid').val(),
        FirstName: $('#FirstName').val(),
        LastName: $('#LastName').val(),
        Email: $('#Email').val(),
        PhoneCode: $('#PhoneCode').val(),
        City: $('#City').val(),
        State: $('#State').val(),
        Country: $('#Country').val(),
        Pincode: $('#Pincode').val(),
        Employer: $('#Employer').val(),
        Fromdate: $('#Fromdate').val(),
        Todate: $('#Todate').val(),

    };
    $.ajax({
        url: "/Candiate/Update",
        data: JSON.stringify(CandObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            loadData();
            $('#ItemModal').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}
function Delele(ID) {
    var ans = confirm("Are you sure you want to delete this Record?");
    if (ans) {
        $.ajax({
            url: "/Candiate/Delete/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function (result) {
                loadData();
            },
            error: function (errormessage) {
                alert(errormessage.responseText);
            }
        });
    }
}
function clearTextBox() {
    $('#cdid').val("");
    $('#FirstName').val("");
    $('#btnUpdate').hide();
    $('#btnAdd').show();
    $('#ItemName').css('border-color', 'lightgrey');
}
function validate() {
    var isValid = true;
    if ($('#FirstName').val().trim() == "") {
        $('#FirstName').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#FirstName').css('border-color', 'lightgrey');
    }
    if ($('#Email').val().trim() == "") {
        $('#Email').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Email').css('border-color', 'lightgrey');
    }
    if ($('#Country').val().trim() == "") {
        $('#Country').css('border-color', 'Red');
        isValid = false;
    }
    else {
        $('#Country').css('border-color', 'lightgrey');
    }
    return isValid;
}