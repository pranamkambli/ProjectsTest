﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CandidateAssessmentSystem.Models
{
    public class CandiateController : Controller
    {
        //
        // GET: /Candiate/
        CandiateManagerDBEntities candiateManage = null;
        public CandiateController()
        {
            candiateManage = new CandiateManagerDBEntities();
        }

        public ActionResult Index()
        {
            return View();
        }
        public JsonResult List(string SearchText)
        {
            if (SearchText == null || SearchText.Trim() == "" || SearchText == string.Empty)
            {
                List<Candiate> candiate = candiateManage.Candiates.ToList();
                return Json(candiate, JsonRequestBehavior.AllowGet);
            }
            else if (SearchText != null || SearchText.Trim() != "")
            {
                List<Candiate> CandiateSearch = candiateManage.Candiates.ToList().Where(x => x.FirstName.Contains(SearchText.ToString())).ToList(); // || x.LastName.Contains(SearchText.ToString())).ToList();
                return Json(CandiateSearch, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(null, JsonRequestBehavior.AllowGet);
            }
        }
        public JsonResult Add(Candiate candiate)
        {
            candiateManage.Candiates.Add(candiate);
            candiateManage.SaveChanges();
            return Json(JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetbyID(int Cdid)
        {
            return Json(candiateManage.Candiates.FirstOrDefault(x => x.cdid == Cdid), JsonRequestBehavior.AllowGet);
        }
        public JsonResult Update(Candiate candiate)
        {
            var data = candiateManage.Candiates.FirstOrDefault(x => x.cdid == candiate.cdid);
            if (data != null)
            {
                data.LastName = candiate.LastName;
                data.Email = candiate.Email;
                data.PhoneCode = candiate.PhoneCode;
                data.City = candiate.City;
                data.State = candiate.State;
                data.Country = candiate.Country;
                data.Pincode = candiate.Pincode;
                data.Employer = candiate.Employer;
                data.Fromdate = candiate.Fromdate;
                data.Todate = candiate.Todate;
                data.FirstName = candiate.FirstName;

                candiateManage.SaveChanges();
            }
            return Json(JsonRequestBehavior.AllowGet);
        }
        public JsonResult Delete(int ID)
        {
            var data = candiateManage.Candiates.FirstOrDefault(x => x.cdid == ID);
            if (data != null)
            {

                candiateManage.Candiates.Remove(data);
                candiateManage.SaveChanges();
            }
            return Json(JsonRequestBehavior.AllowGet);
        }

    }
}
